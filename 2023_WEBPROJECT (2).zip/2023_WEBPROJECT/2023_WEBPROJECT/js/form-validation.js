// Attachs an event handler to the document object that will run when the page finishes loading
$(document).ready(function () {
// Uses the jQuery Validation Plugin to add form validation to the #validation form
  $("#validation").validate({
//used for validation rules for each input field in my form
    rules: {
      name: {
        required: true,
        minlength: 3,
      },
      phone: {
        required: true,
        digits: true,
        minlength: 8,
      },
      address: {
        required: true,
        minlength: 5,
      },
      postal: {
        required: true,
        minlength: 5,
      },
        
      city: {required: true,
             minlength: 3,
            },
        
      email: {
        required: true,
        email: true,
      },
    },
      
      
    messages: {
        
        
      name: {
        required: "Please enter your name",
        minlength: "Minimum length is 3 characters",
      },
    
      address: "Minimum length is 5 characters",
        
        
      phone: {
        digits: "Please enter digits only",
        required: "Phone number is required",
        minlength: "Please enter at least 8 numbers",
      },
        
      postal: {
        required: "Please provide a password",
        minlength: "Your postal code must be at least 5 characters long",
      },
        
      city: "Please enter a valid city",
      email: "Please enter a valid email address",
    },
//what happens when the form is submitted and all inputs are valid
    submitHandler: function (form) {
        window.location.href = "thank-you.html";
    },
  });
});