function productTotals() {
    //declaring price variables
    let price1 = 25;
    let price2 = 150;
    let price3 = 100;
    let price4 = 75;
    let price5 = 50;
    //getting input from form and storing in variables
    let quantity1 = document.querySelector("#youtoozQuant").value;
    let quantity2 = document.querySelector("#deskQuant").value;
    let quantity3 = document.querySelector("#chairQuant").value;
    let quantity4 = document.querySelector("#hoodieQuant").value;
    let quantity5 = document.querySelector("#scienceQuant").value;
    //calculations
    let total1 = eval(quantity1) * eval(price1);
    let total2 = eval(quantity2) * eval(price2);
    let total3 = eval(quantity3) * eval(price3);
    let total4 = eval(quantity4) * eval(price4);
    let total5 = eval(quantity5) * eval(price5);
    let grandTotal = eval(total1) + eval(total2) + eval(total3) + eval(total4) + eval(total5);
    //returning new values to form
    document.querySelector("#total1").value = total1;
    document.querySelector("#total2").value = total2;
    document.querySelector("#total3").value = total3;
    document.querySelector("#total4").value = total4;
    document.querySelector("#total5").value = total5;
    document.querySelector("#grandTotal").value = grandTotal;
}

function checkout(){
    //declaring variables
    let totalExShipping = document.querySelector("#grandTotal").value;
    let quantity1 = document.querySelector("#youtoozQuant").value;
    let quantity2 = document.querySelector("#deskQuant").value;
    let quantity3 = document.querySelector("#chairQuant").value;
    let quantity4 = document.querySelector("#hoodieQuant").value;
    let quantity5 = document.querySelector("#scienceQuant").value;
    let shippingBase = 0.50;
    //calculating shipping cost
    let shippingCost = eval(shippingBase) * (eval(quantity1) + eval(quantity2) + eval(quantity3) + eval(quantity4) + eval(quantity5));
    //Calculating final cost
    let totalIncShipping = eval(totalExShipping) + eval(shippingCost);
    //alert detailing shipping costs and final total
     alert("Your Total Before Shipping Costs is: " + "€" + totalExShipping + ", Your Shipping Cost is: " + "€" + shippingCost + " and Your Overall Total due is: " + "€" + totalIncShipping + " Thank you!");
}